# What is a collection?

A collection is a distribution format for delivering all types of Ansible Content.

To learn more about using and creating collections, [check out the official documentation here](https://docs.ansible.com/ansible/devel/dev_guide/collections_tech_preview.html)
